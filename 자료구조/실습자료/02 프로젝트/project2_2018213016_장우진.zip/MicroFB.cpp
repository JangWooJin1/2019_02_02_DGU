﻿#include"facebook.h"

int main() {
	Manage op;
	char cmd;
	string name;
	string name2;
	do
	{
		cout << endl;
		cout << "P <name> - Create a person record of the specified name. You may assume that no two people have the same name." << endl;
		cout << "F <name1> <name2> - Record that the two specified people are friends" << endl;
		cout << "U <name1> <name2> - Record that the ewo specified people are no longer friends" << endl;
		cout << "L <name> - Print out the friends of the specified person" << endl;
		cout << "Q <name1> <name2> - Check whether the two people are friends. If so, print \"Yes\" ; if not, print \"NO\"" << endl;
		cout << "X - terminate the program." << endl;
		cout << endl << "Command: ";                  // Read command
		cin >> cmd;

		switch (cmd)
		{
		case 'P': case 'p':
			cin >> name;
			op.Put(name);
			break;

		case 'F': case 'f':
			cin >> name >> name2;
			op.Friend(name,name2);
			break;

		case 'U': case 'u':
			cin >> name >> name2;
			op.Unfriend(name,name2);
			break;

		case 'L': case 'l':
			cin >> name;
			cout << "-> ";
			op.L(name);
			break;

		case 'Q': case 'q':
			cin >> name >> name2;
			if (op.Q(name, name2)) {
				cout << "-> Yes" << endl;
			}
			else {
				cout << "-> No" << endl;
			}
			break;


		case 'X': case 'x':                   // Quit test program
			break;

		default:                               // Invalid command
			cout << "Inactive or invalid command" << endl;
		}
		//op.testtest();
	} while (cmd != 'X' && cmd != 'x');

}