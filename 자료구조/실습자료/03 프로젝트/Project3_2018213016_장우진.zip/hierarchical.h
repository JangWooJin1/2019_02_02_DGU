#pragma once

#include<iostream>
#include<string>

using namespace std;

class TreeNode {
public:
	TreeNode(string name, TreeNode* child, TreeNode* sibling);
	friend class Tree;

private:
	string name;
	TreeNode* child;
	TreeNode* sibling;
};

class Tree {
public:
	Tree(string ceo);
	void Insert(string employer, string employee);
	void Delete(string name);
	void Showstruct();

private:
	void InsertSub(TreeNode*& p, string employer, string employee, bool &found);
	void DeleteSub(TreeNode *&p, string name, bool &found);
	void ShowstructSub(TreeNode* p, int level) const;
	TreeNode* CEO;
};


