#include"hierarchical.h"

int main() {

	cout << "[Existing member] hires [new member]" << endl;
	cout << "Fire[existing member]" << endl;
	cout << "Print" << endl << endl;

	string n1,n2,n3,ceo;
	cin >> ceo;
	Tree t(ceo);


	while (1) {
		cin >> n1;
		if(n1=="Fire" || n1 == "fire"){
			cin >> n2;
			t.Delete(n2);
		}
		else if (n1 == "print" || n1 == "Print") {
			t.Showstruct();
		}
		else {
			cin >> n2 >> n3;
			if (n2 == "hires") {
				t.Insert(n1,n3);
			}
			else {
				cout << "invaild operation" << endl;
			} 
		}
	}

}
