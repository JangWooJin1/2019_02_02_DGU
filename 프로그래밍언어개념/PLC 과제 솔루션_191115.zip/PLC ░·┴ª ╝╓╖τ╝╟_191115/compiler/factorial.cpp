int main ( ) {
    int n, i, f;
    n = 3;
    i = 1;
    f = 1;
    while (i < n) {
        i = i + 1;
        f = f * i;
    }
}
